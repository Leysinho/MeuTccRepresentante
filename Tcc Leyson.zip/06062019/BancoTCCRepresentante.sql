﻿CREATE DATABASE TccRepresentante;
GO

USE TccRepresentante;
GO


CREATE TABLE Alunos
(
Aluno VARCHAR (70) NOT NULL,
CGM INT PRIMARY KEY NOT NULL,
Turma VARCHAR(30),
Representante BIT NOT NULL
);
GO

CREATE TABLE Turmas
(
IDTurma INT PRIMARY KEY IDENTITY NOT NULL,
Nome VARCHAR (30) NOT NULL
);
GO

CREATE TABLE LoginUsuarios
(
Usuario varchar(30) PRIMARY KEY,
Senha VARCHAR (30) NOT NULL
);
GO

CREATE TABLE Voto
(
candiato int primary key identity,
Aluno INT FOREIGN KEY references ALUNOS (CGM),
Voto INT NOT NULL
);

INSERT INTO LoginUsuarios values
(
	'Admin',
	'admin123'
);

INSERT INTO Turmas values
(

'1º Ano A'
);


select * from alunos;
select * from Voto;
SELECT * FROM LoginUsuarios

delete from alunos
delete from voto
delete FROM LoginUsuarios where Usuario in ('alunos representante 1','charles gentilin')




